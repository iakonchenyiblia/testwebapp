# MVP Crypto ML — Full deployment guide (Timeweb Cloud / any VPS)

Этот пакет содержит минимальную рабочую версию проекта: статический фронтенд (TradingView widget) и backend (FastAPI) с демонстрационным Binance streamer и заглушкой модели.
Фронтенд и бэкенд упакованы под Docker Compose. Предполагается домен и VPS (Ubuntu 22.04).

---
## 1) Подготовка сервера (Ubuntu 22.04)

Выполни на сервере (SSH):
```bash
sudo apt update && sudo apt upgrade -y
# установить Docker
sudo apt install -y ca-certificates curl gnupg lsb-release
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] \
  https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io
# docker compose plugin
sudo apt install -y docker-compose-plugin
# добавить текущего пользователя в docker группу (опционально)
sudo usermod -aG docker $USER
newgrp docker
```

---
## 2) Развёртывание проекта на сервере

Скопируй содержимое архива в `/opt/mvp-crypto-ml`:
```bash
sudo mkdir -p /opt/mvp-crypto-ml
sudo chown $USER:$USER /opt/mvp-crypto-ml
# загрузить архив на сервер или git clone, затем распаковать/скопировать в /opt/mvp-crypto-ml
# например, если архив в домашней папке:
unzip full_mvp_repo.zip -d /opt/mvp-crypto-ml
cd /opt/mvp-crypto-ml
```

Скопируй `.env.example` в `backend/.env` и настрой переменные:
```bash
cp backend/.env.example backend/.env
# отредактируй backend/.env, укажи BINANCE_SYMBOLS=btcusdt,ethusdt
```

Запусти стек:
```bash
docker compose up -d --build
```

Проверка:
- Backend: `curl http://127.0.0.1:8000/api/health`
- Frontend (локально на сервере): `curl http://127.0.0.1:8080`

---
## 3) Настройка Nginx + Let's Encrypt (рекомендуется)

Установи nginx и certbot:
```bash
sudo apt install -y nginx
sudo apt install -y certbot python3-certbot-nginx
```

Создай конфигурацию (пример в `nginx-proxy-example.conf`), сохрани `/etc/nginx/sites-available/mvp` и включи её:
```bash
sudo cp nginx-proxy-example.conf /etc/nginx/sites-available/mvp
sudo ln -s /etc/nginx/sites-available/mvp /etc/nginx/sites-enabled/mvp
sudo nginx -t && sudo systemctl reload nginx
```

Получение сертификата (замени `your.domain.tld`):
```bash
sudo certbot --nginx -d your.domain.tld
```

После этого frontend будет доступен по HTTPS, а запросы `/api/` будут проксироваться к backend.

---
## 4) Автозапуск после перезагрузки

Скопируй systemd-юнит в `/etc/systemd/system/mvp.service` и активируй:
```bash
sudo cp mvp.service /etc/systemd/system/mvp.service
sudo systemctl daemon-reload
sudo systemctl enable mvp.service
sudo systemctl start mvp.service
```

---
## 5) Как работать (локально/на телефоне)

- Открой https://your.domain.tld — увидишь TradingView график и кнопку 'Get prediction', которая вызывает `GET /api/predict?symbol=...`.
- Для доступа к реальному стриму и ML-предсказаниям отладь `backend/app/binance_ws.py` и `backend/app/model_stub.py`.

---
## 6) Следующие шаги (если хочешь продолжить разворачивать ML-пайплайн)

- Подключить persistent DB (Postgres / Timescale) для хранения исторических свечей и логов сделок.
- Выделить Redis для очередей/кеша (если много подписок).
- Заменить ModelStub на реальную модель и хранить в `/opt/models`. Для деплоя модели можно использовать TorchScript или joblib (для sklearn/xgboost).
- При высокой нагрузке — вынести ML-инференс в отдельный контейнер, при необходимости подключить GPU-сервер.

---
Если хочешь, могу сгенерировать более продвинутый репозиторий с React-приложением и примером ML-notebook.
