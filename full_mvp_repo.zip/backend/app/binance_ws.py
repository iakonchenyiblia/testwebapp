import asyncio
import json
import websockets
from collections import defaultdict
import time

class BinanceStreamer:
    def __init__(self, symbols=None):
        if symbols is None:
            symbols = ["btcusdt"]
        self.symbols = [s.lower().strip() for s in symbols if s]
        self.klines = defaultdict(list)
        self.orderbooks = defaultdict(lambda: {"bids": [], "asks": []})
        self._running = False

    async def _connect_combined(self, streams):
        url = f"wss://stream.binance.com:9443/stream?streams={streams}"
        async with websockets.connect(url, ping_interval=20, ping_timeout=10) as ws:
            async for msg in ws:
                data = json.loads(msg)
                payload = data.get("data", {})
                await self._handle(payload)

    async def _handle(self, payload):
        # kline event
        if payload.get("e") == "kline":
            s = payload.get("s","").lower()
            k = payload.get("k", {})
            try:
                candle = {
                    "t": k.get("t"),
                    "o": float(k.get("o")),
                    "h": float(k.get("h")),
                    "l": float(k.get("l")),
                    "c": float(k.get("c")),
                    "v": float(k.get("v")),
                    "is_closed": k.get("x", False),
                }
            except Exception:
                return
            arr = self.klines[s]
            arr.append(candle)
            if len(arr) > 1000:
                arr.pop(0)
        elif payload.get("e") == "depthUpdate":
            s = payload.get("s","").lower()
            bids = payload.get("b", [])
            asks = payload.get("a", [])
            try:
                self.orderbooks[s]["bids"] = [[float(price), float(qty)] for price, qty in bids[:10]]
                self.orderbooks[s]["asks"] = [[float(price), float(qty)] for price, qty in asks[:10]]
            except Exception:
                pass

    async def run(self):
        if self._running:
            return
        self._running = True
        # Build streams string
        kline_streams = "/".join([f"{s}@kline_1m" for s in self.symbols])
        depth_streams = "/".join([f"{s}@depth5@100ms" for s in self.symbols])
        streams = kline_streams + "/" + depth_streams
        while True:
            try:
                await self._connect_combined(streams)
            except Exception as e:
                print("Binance WS error, reconnecting:", e)
                await asyncio.sleep(5)
            await asyncio.sleep(0.1)

    def get_latest(self, symbol):
        symbol = symbol.lower()
        return {
            "klines": list(self.klines.get(symbol, []))[-200:],
            "orderbook": self.orderbooks.get(symbol, {})
        }
