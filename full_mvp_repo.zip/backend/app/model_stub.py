import random

class ModelStub:
    def __init__(self):
        pass

    def predict_simple(self, data):
        try:
            klines = data.get("klines", [])
            last = klines[-1]["c"] if klines else 0.0
        except Exception:
            last = 0.0
        p_up = round(random.uniform(0.35, 0.7), 3)
        sl = round(last * (1 - 0.01), 6)
        tp = round(last * (1 + 0.02), 6)
        return {
            "probability_up": p_up,
            "last_price": last,
            "suggested_entry": last,
            "suggested_sl": sl,
            "suggested_tp": tp,
            "note": "Demo model. Replace with trained model for real signals."
        }
