import asyncio
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .binance_ws import BinanceStreamer
from .model_stub import ModelStub
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="MVP Crypto ML API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# init streamer and model
streamer = BinanceStreamer(symbols=os.getenv("BINANCE_SYMBOLS","btcusdt").split(","))
model = ModelStub()

@app.on_event("startup")
async def startup_event():
    # start the streamer in the background
    loop = asyncio.get_event_loop()
    loop.create_task(streamer.run())

@app.get("/api/health")
async def health():
    return {"status":"ok"}

@app.get("/api/predict")
async def predict(symbol: str = "btcusdt"):
    s = symbol.lower()
    data = streamer.get_latest(s)
    if not data:
        raise HTTPException(status_code=404, detail="no data for symbol")
    pred = model.predict_simple(data)
    return pred
